let darkMode = true;
let adminUnlocked = false;

function toggleTheme() {
  darkMode = !darkMode;
  document.body.classList.toggle('light', !darkMode);
  document.querySelector('header').classList.toggle('light', !darkMode);
  document.querySelector('footer').classList.toggle('light', !darkMode);
}

function toggleMenu() {
  if (!adminUnlocked) {
    document.getElementById("admin-panel").classList.toggle("hidden");
  }
}

function checkPassword(event) {
  if (event.key === "Enter") {
    const pass = document.getElementById("admin-password").value;
    if (pass === "arsenije2005") {
      adminUnlocked = true;
      document.getElementById("admin-panel").classList.add("hidden");
      document.getElementById("admin-controls").classList.remove("hidden");
    } else {
      alert("Pogrešna lozinka");
    }
  }
}

// Kontakt podaci
const emailInput = document.getElementById("contact-email");
const phoneInput = document.getElementById("contact-phone");
const locationInput = document.getElementById("contact-location");
const footerContact = document.getElementById("footer-contact");

function updateFooter() {
  footerContact.textContent = \`\${emailInput.value} | \${phoneInput.value} | \${locationInput.value}\`;
}

if (emailInput && phoneInput && locationInput) {
  emailInput.addEventListener("input", updateFooter);
  phoneInput.addEventListener("input", updateFooter);
  locationInput.addEventListener("input", updateFooter);
}
